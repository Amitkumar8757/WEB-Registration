﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Registration.Models;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;

namespace Registration.Controllers
{
    public class RegisterController : Controller
    {
        private ApplicationDbContext dbContext;

        public RegisterController(ApplicationDbContext Context)
        {
            dbContext = Context;
        }
        public IActionResult Index()
        {
            var rms = dbContext.RegisterModels.ToList();
            return View(rms);
        }
        public IActionResult Create()
        {
            return View();
        }
        [HttpPost]
        public IActionResult Create(RegisterModel register)
        {
            dbContext.Add(register);
            dbContext.SaveChanges();
            return RedirectToAction("Index");
        }
        public IActionResult Edit(int Id)
        {
            var RegisterModel = dbContext.RegisterModels.SingleOrDefault(r => r.Id == Id);
            return View(RegisterModel);
        }
        [HttpPost]
        public IActionResult Edit(RegisterModel objRegisterModel)
        {
            var RegisterModel = dbContext.RegisterModels.Where(r => r.Id == objRegisterModel.Id).FirstOrDefault();
            if (RegisterModel != null)
            {
                RegisterModel.Name = objRegisterModel.Name;
                RegisterModel.Contact = objRegisterModel.Name;
                RegisterModel.Gender = objRegisterModel.Gender;
                RegisterModel.Category = objRegisterModel.Category;
                RegisterModel.Address = objRegisterModel.Address;
                dbContext.Entry(RegisterModel).State = EntityState.Modified;
                int result = dbContext.SaveChanges();
                if (result > 0)
                {
                    return RedirectToAction("Index");
                }

            }
            return View();
        }
        public IActionResult Delete(int Id)
        {
            var RegisterModel = dbContext.RegisterModels.SingleOrDefault(r => r.Id == Id);

            RegisterModel.Id = Id;
        

            dbContext.Entry(RegisterModel).State = EntityState.Deleted;
            int result = dbContext.SaveChanges();
            if(result>0)
            {
                RedirectToAction("Index");

            }
            return View();
        }
    }
}
